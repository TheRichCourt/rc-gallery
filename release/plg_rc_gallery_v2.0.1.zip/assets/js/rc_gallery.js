jQuery(document).ready(function() {
    resizeGallery();
});
jQuery(window).resize(function() {
    resizeGallery();
});

function resizeGallery() {
    
    jQuery('.rc_gallery').each(function() {
        //get the params for this gallery
        var startHeight = jQuery(this).attr("data-start-height");
        var marginSize = jQuery(this).attr("data-margin-size");
        
        var targetLineWidth = jQuery(this).width() - 1;
        var currentLineWidth = 0;
        var imageWidthArray = new Array();
        var imageRatioArray = new Array();
        var imageLineNumberArray = new Array();
        var lineWidthArray = new Array();
        var imageID = 0;
        var lineID = 0;
        jQuery(this).find('.rc_galleryimg').each(function() {
            var w = jQuery(this).attr("data-width");
            var h = jQuery(this).attr("data-height");
            imageRatioArray[imageID] = w / h;
            jQuery(this).height(startHeight);
            jQuery(this).width((startHeight / h) * w);
            if ((currentLineWidth + jQuery(this).width() + (2 * marginSize)) >= targetLineWidth) {
                lineWidthArray[lineID] = currentLineWidth;
                lineID++;
                currentLineWidth = jQuery(this).width() + (2 * marginSize);
            } else {
                currentLineWidth = currentLineWidth + jQuery(this).width() + (2 * marginSize);
                lineWidthArray[lineID] = currentLineWidth;
            }
            imageWidthArray[imageID] = jQuery(this).width() + (2 * marginSize);
            imageLineNumberArray[imageID] = lineID;
            if (imageID == 8) {
                var x = 0;
            }
            imageID++;
        });
        var imageCount = imageWidthArray.length;
        var targetImgWidthArray = new Array();
        var targetLineHeightArray = new Array();
        var currentLineNo = -1;
        for (var i = 0; i <= imageCount; i++) {
            var imgWidth = imageWidthArray[i];
            var lineNo = imageLineNumberArray[i];
            var lineWidth = lineWidthArray[lineNo];
            if (!lineWidth) {
                lineWidth = targetLineWidth - (2 * marginSize);
            }
            targetImgWidthArray[i] = ((imgWidth / lineWidth) * targetLineWidth) - (2 * marginSize);
            if (targetImgWidthArray[i] + (2 * marginSize) > (targetLineWidth - (2 * marginSize))) {
                targetImgWidthArray[i] = targetLineWidth - (2 * marginSize);
            }
            if (currentLineNo != lineNo) {
                targetLineHeightArray[lineNo] = (targetImgWidthArray[i] - (2 * marginSize)) / imageRatioArray[i];
                currentLineNo = lineNo;
            }
        }
        imageID = 0;
        jQuery(this).find('.rc_galleryimg').each(function() {
            jQuery(this).width(targetImgWidthArray[imageID]);
            jQuery(this).height(targetLineHeightArray[imageLineNumberArray[imageID]]);
            imageID++;
        });
    });
}